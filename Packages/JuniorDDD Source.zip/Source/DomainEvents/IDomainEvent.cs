namespace Junior.Ddd.DomainEvents
{
	/// <summary>
	/// Represents a domain event. <see cref="IDomainEvent"/> is a marker interface.
	/// </summary>
	public interface IDomainEvent
	{
	}
}
﻿using System.Reflection;

[assembly:AssemblyTitle("Junior.Ddd.UnitTests")]